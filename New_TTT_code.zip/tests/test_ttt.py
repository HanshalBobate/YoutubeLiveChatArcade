import unittest

from app.games import CommandResult, TicTacToeGame, render_to_string


class TicTacToeTests(unittest.TestCase):
    def setUp(self):
        self.game = TicTacToeGame()

    def join_two(self):
        self.assertEqual(
            self.game.handle_command("!ttt join", "u1", "Alice"),
            CommandResult.EXECUTED,
        )
        self.assertEqual(
            self.game.handle_command("!ttt join", "u2", "Bob"),
            CommandResult.EXECUTED,
        )

    def test_initial_state(self):
        self.assertEqual(self.game.player_count, 0)
        self.assertFalse(self.game.started)
        self.assertFalse(self.game.is_finished())

    def test_duplicate_join_is_rejected(self):
        self.assertEqual(
            self.game.handle_command("!ttt join", "u1", "Alice"),
            CommandResult.EXECUTED,
        )
        self.assertEqual(
            self.game.handle_command("!ttt join", "u1", "Alice"),
            CommandResult.INVALID,
        )
        self.assertEqual(self.game.player_count, 1)

    def test_third_player_is_rejected(self):
        self.join_two()
        self.assertEqual(
            self.game.handle_command("!ttt join", "u3", "Carol"),
            CommandResult.INVALID,
        )
        self.assertEqual(self.game.player_count, 2)

    def test_move_before_two_players_is_rejected(self):
        self.assertEqual(
            self.game.handle_command("!ttt 1", "u1", "Alice"),
            CommandResult.INVALID,
        )

    def test_wrong_player_cannot_move(self):
        self.join_two()
        self.assertEqual(
            self.game.handle_command("!ttt 1", "u2", "Bob"),
            CommandResult.INVALID,
        )
        self.assertEqual(self.game.board[0], " ")

    def test_valid_move_and_turn_switch(self):
        self.join_two()
        self.assertEqual(
            self.game.handle_command("!ttt 1", "u1", "Alice"),
            CommandResult.EXECUTED,
        )
        self.assertEqual(self.game.board[0], "X")
        self.assertEqual(self.game.turn, "O")

    def test_occupied_square_is_rejected(self):
        self.join_two()
        self.game.handle_command("!ttt 1", "u1", "Alice")
        self.assertEqual(
            self.game.handle_command("!ttt 1", "u2", "Bob"),
            CommandResult.INVALID,
        )

    def test_x_wins(self):
        self.join_two()
        moves = [
            ("!ttt 1", "u1"),
            ("!ttt 4", "u2"),
            ("!ttt 2", "u1"),
            ("!ttt 5", "u2"),
            ("!ttt 3", "u1"),
        ]

        for command, user_id in moves:
            self.assertEqual(
                self.game.handle_command(command, user_id, "user"),
                CommandResult.EXECUTED,
            )

        self.assertTrue(self.game.is_finished())
        self.assertEqual(self.game.winner, "X")

        # Finished game rejects moves.
        self.assertEqual(
            self.game.handle_command("!ttt 6", "u2", "Bob"),
            CommandResult.INVALID,
        )

    def test_draw(self):
        self.join_two()
        moves = [
            ("!ttt 1", "u1"),
            ("!ttt 2", "u2"),
            ("!ttt 3", "u1"),
            ("!ttt 5", "u2"),
            ("!ttt 4", "u1"),
            ("!ttt 7", "u2"),
            ("!ttt 8", "u1"),
            ("!ttt 9", "u2"),
            ("!ttt 6", "u1"),
        ]

        for command, user_id in moves:
            self.assertEqual(
                self.game.handle_command(command, user_id, "user"),
                CommandResult.EXECUTED,
            )

        self.assertTrue(self.game.is_finished())
        self.assertEqual(self.game.winner, "DRAW")

    def test_restart_after_finished_game(self):
        self.join_two()

        moves = [
            ("!ttt 1", "u1"),
            ("!ttt 4", "u2"),
            ("!ttt 2", "u1"),
            ("!ttt 5", "u2"),
            ("!ttt 3", "u1"),
        ]

        for command, user_id in moves:
            self.game.handle_command(command, user_id, "user")

        self.assertTrue(self.game.is_finished())

        # First join after completion resets and joins X.
        self.assertEqual(
            self.game.handle_command("!ttt join", "u3", "Carol"),
            CommandResult.EXECUTED,
        )
        self.assertFalse(self.game.is_finished())
        self.assertEqual(self.game.player_count, 1)
        self.assertEqual(self.game.players["X"], "u3")
        self.assertEqual(self.game.players["O"], None)

    def test_invalid_command_does_not_change_state(self):
        self.join_two()
        before = self.game.board.copy()
        self.assertEqual(
            self.game.handle_command("!banana", "u1", "Alice"),
            CommandResult.INVALID,
        )
        self.assertEqual(self.game.board, before)
        self.assertEqual(self.game.turn, "X")

    def test_render_is_rectangular(self):
        frame = self.game.render()
        self.assertTrue(frame)
        width = len(frame[0])
        self.assertTrue(all(len(row) == width for row in frame))
        self.assertTrue(all(len(cell) == 1 for row in frame for cell in row))

        text = render_to_string(frame)
        self.assertIn("TIC TAC TOE", text)
        self.assertEqual(len(text.splitlines()), len(frame))


if __name__ == "__main__":
    unittest.main()
