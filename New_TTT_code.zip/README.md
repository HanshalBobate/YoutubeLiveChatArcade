# YouTube Chat Arcade — Tic-Tac-Toe Core

Production-oriented, dependency-free core for the YouTube Chat Arcade.

## Supported commands

```text
!ttt join
!ttt 1
!ttt 2
...
!ttt 9
```

The first two unique users become X and O. Only the player whose turn it is can move.

## Important behavior

- Invalid commands return `CommandResult.INVALID`.
- Successfully executed commands return `CommandResult.EXECUTED`.
- A move that targets an occupied square is invalid.
- A move from the wrong player is invalid.
- The board is checked immediately after every successful move.
- A finished game remains rendered until `!ttt join` is received.
- `!ttt join` after a finished game safely starts a fresh game.
- Rendering always returns a rectangular `list[list[str]]`.
- `render_to_string()` produces the exact text suitable for an OBS text source.
- No external dependencies are required.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Integration contract

Your future GameManager should treat `EXECUTED` as the only result that consumes
the current action window. `INVALID` means the next queued chat message should
be tried immediately.
