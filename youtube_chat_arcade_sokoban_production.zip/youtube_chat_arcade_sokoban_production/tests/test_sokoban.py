import pytest

from app.games import CommandResult, Sokoban, render_to_string


def test_initial_state_and_render():
    game = Sokoban()
    assert game.level_name == "First Steps"
    assert game.moves == 0
    assert game.pushes == 0
    assert not game.is_finished()

    frame = game.render()
    assert len(frame) == 5
    assert len({len(row) for row in frame}) == 1
    text = render_to_string(frame)
    assert "@" in text
    assert "$" in text
    assert "." in text


def test_invalid_command_does_not_change_state():
    game = Sokoban()
    before = (game.player, game.crates, game.moves, game.pushes)

    assert game.handle_command("hello", "u1", "alice") is CommandResult.INVALID
    assert (game.player, game.crates, game.moves, game.pushes) == before


def test_wall_move_is_invalid():
    game = Sokoban()
    # Reach the bottom row, then try to walk through its wall.
    assert game.handle_command("!down", "u1", "alice") is CommandResult.EXECUTED
    before = game.player
    assert game.handle_command("!down", "u1", "alice") is CommandResult.INVALID
    assert game.player == before
    assert game.moves == 1


def test_push_moves_crate_and_player():
    game = Sokoban()
    # First Steps: player at col 5, crate at col 4.
    result = game.handle_command("!left", "u1", "alice")
    assert result is CommandResult.EXECUTED
    assert game.player.col == 4
    assert any(pos.col == 3 for pos in game.crates)
    assert game.moves == 1
    assert game.pushes == 1


def test_blocked_push_is_invalid():
    game = Sokoban()
    # Push the crate onto the goal.
    assert game.handle_command("!left", "u1", "alice") is CommandResult.EXECUTED
    assert game.handle_command("!left", "u1", "alice") is CommandResult.EXECUTED

    # Player is immediately right of the crate; another left would push it
    # through the goal into the wall.
    assert game.handle_command("!left", "u1", "alice") is CommandResult.INVALID


def test_solve_level():
    game = Sokoban()
    # Move player around the crate and push it left onto the goal.
    commands = ["!left", "!left"]
    for command in commands:
        assert game.handle_command(command, "u1", "alice") is CommandResult.EXECUTED

    assert game.is_finished()
    assert game.crates == game.goals


def test_finished_game_rejects_commands():
    game = Sokoban()
    for command in ["!left", "!left"]:
        game.handle_command(command, "u1", "alice")

    before = (game.player, game.crates, game.moves)
    assert game.handle_command("!right", "u2", "bob") is CommandResult.INVALID
    assert (game.player, game.crates, game.moves) == before


def test_reset():
    game = Sokoban()
    game.handle_command("!left", "u1", "alice")
    game.reset()
    assert game.level_index == 0
    assert game.moves == 0
    assert game.pushes == 0
    assert game.player.col == 5
    assert not game.is_finished()


def test_next_level():
    game = Sokoban()
    assert game.next_level() is True
    assert game.level_index == 1
    assert game.moves == 0
    assert game.next_level() is True
    assert game.level_index == 2
    assert game.next_level() is False


def test_render_is_rectangular():
    game = Sokoban()
    frame = game.render()
    width = len(frame[0])
    assert all(len(row) == width for row in frame)
    assert all(len(cell) == 1 for row in frame for cell in row)


def test_aliases_and_whitespace():
    game = Sokoban()
    assert game.handle_command("  !l  ", "u1", "alice") is CommandResult.EXECUTED
    game.reset()
    assert game.handle_command("!d", "u1", "alice") is CommandResult.EXECUTED


def test_extra_tokens_are_invalid():
    game = Sokoban()
    before = (game.player, game.moves)
    assert game.handle_command("!left now", "u1", "alice") is CommandResult.INVALID
    assert (game.player, game.moves) == before


def test_invalid_level_index():
    with pytest.raises(ValueError):
        Sokoban(999)
