# YouTube Chat Arcade — Sokoban

Production-oriented, dependency-light Sokoban game engine for a shared YouTube Live chat controller.

## Rules

The entire chat controls one shared player. Each accepted command advances exactly one Sokoban action.

Supported commands:

- `!up` / `!u`
- `!down` / `!d`
- `!left` / `!l`
- `!right` / `!r`

A command is `EXECUTED` only when it produces a legal state change. Invalid syntax, wall collisions, and impossible pushes return `INVALID`.

This distinction is intentional: the external GameManager can discard invalid chat messages immediately and continue scanning the queue instead of consuming the 5-second action window.

## Rendering

`render()` returns `list[list[str]]`, with one character per cell.

`render_to_string()` converts it into an OBS-friendly multiline string.

Glyphs:

- `#` wall
- ` ` floor
- `.` goal
- `$` crate
- `@` player
- `*` crate on goal
- `+` player on goal

## Timing

There is **no automatic timer or movement** inside Sokoban. The 5-second "first valid command wins" rule belongs in the outer GameManager/command queue, not the game itself.

## Level lifecycle

- `Sokoban()` loads level 0.
- `reset()` restarts the current level.
- `next_level()` advances to the next built-in level.
- `is_finished()` becomes true when every crate is on a goal.
- Finished games reject further commands until reset/level transition.

## Tests

Run:

```bash
python -m pytest -q
```

The package is dependency-free at runtime; pytest is only needed for tests.
