from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar


from .base import CommandResult, Game


@dataclass(frozen=True)
class Position:
    row: int
    col: int


@dataclass(frozen=True)
class Level:
    name: str
    rows: tuple[str, ...]


class Sokoban(Game):
    """Turn-based Sokoban for a shared YouTube-chat controller.

    The chat is one shared player. A command is accepted only when it causes
    a legal state change. Invalid commands do not consume the action window;
    the surrounding GameManager can immediately try the next queued message.
    """

    WALL: ClassVar[str] = "#"
    FLOOR: ClassVar[str] = " "
    GOAL: ClassVar[str] = "."
    CRATE: ClassVar[str] = "$"
    PLAYER: ClassVar[str] = "@"
    CRATE_ON_GOAL: ClassVar[str] = "*"
    PLAYER_ON_GOAL: ClassVar[str] = "+"

    COMMANDS: ClassVar[dict[str, tuple[int, int]]] = {
        "!up": (-1, 0),
        "!u": (-1, 0),
        "!down": (1, 0),
        "!d": (1, 0),
        "!left": (0, -1),
        "!l": (0, -1),
        "!right": (0, 1),
        "!r": (0, 1),
    }

    LEVELS: ClassVar[tuple[Level, ...]] = (
        Level(
            "First Steps",
            (
                "########",
                "#      #",
                "# . $@ #",
                "#      #",
                "########",
            ),
        ),
        Level(
            "Two Boxes",
            (
                "#########",
                "#       #",
                "# . $   #",
                "# . $ @ #",
                "#       #",
                "#########",
            ),
        ),
        Level(
            "Corners",
            (
                "#########",
                "#  .    #",
                "#  $    #",
                "#  ###  #",
                "#    @  #",
                "#########",
            ),
        ),
    )

    def __init__(self, level_index: int = 0) -> None:
        self.level_index = 0
        self.moves = 0
        self.pushes = 0
        self.finished = False
        self._terrain: list[list[str]] = []
        self._goals: set[Position] = set()
        self._crates: set[Position] = set()
        self._player = Position(0, 0)
        self._load_level(level_index)

    @property
    def level_name(self) -> str:
        return self.LEVELS[self.level_index].name

    @property
    def player(self) -> Position:
        return self._player

    @property
    def crates(self) -> frozenset[Position]:
        return frozenset(self._crates)

    @property
    def goals(self) -> frozenset[Position]:
        return frozenset(self._goals)

    @property
    def board(self) -> tuple[tuple[str, ...], ...]:
        """Terrain only, without dynamic player/crate glyphs."""
        return tuple(tuple(row) for row in self._terrain)

    def reset(self, level_index: int | None = None) -> None:
        if level_index is None:
            level_index = self.level_index
        self._load_level(level_index)

    def next_level(self) -> bool:
        if self.level_index + 1 >= len(self.LEVELS):
            return False
        self._load_level(self.level_index + 1)
        return True

    def handle_command(
        self, command: str, user_id: str, username: str
    ) -> CommandResult:
        if self.finished:
            return CommandResult.INVALID

        normalized = command.strip().lower().split()
        if not normalized or normalized[0] not in self.COMMANDS:
            return CommandResult.INVALID

        # Commands must be exactly one token.
        if len(normalized) != 1:
            return CommandResult.INVALID

        dr, dc = self.COMMANDS[normalized[0]]
        target = Position(self._player.row + dr, self._player.col + dc)

        if not self._in_bounds(target) or self._terrain[target.row][target.col] == self.WALL:
            return CommandResult.INVALID

        if target in self._crates:
            beyond = Position(target.row + dr, target.col + dc)
            if (
                not self._in_bounds(beyond)
                or self._terrain[beyond.row][beyond.col] == self.WALL
                or beyond in self._crates
            ):
                return CommandResult.INVALID

            self._crates.remove(target)
            self._crates.add(beyond)
            self._pushes_increment()

        self._player = target
        self.moves += 1
        self.finished = self._is_solved()
        return CommandResult.EXECUTED

    def update(self) -> None:
        # Sokoban is intentionally turn-based. No automatic movement/gravity.
        return None

    def is_finished(self) -> bool:
        return self.finished

    def render(self) -> list[list[str]]:
        frame = [row[:] for row in self._terrain]

        for pos in self._goals:
            frame[pos.row][pos.col] = self.GOAL

        for pos in self._crates:
            frame[pos.row][pos.col] = (
                self.CRATE_ON_GOAL if pos in self._goals else self.CRATE
            )

        player_glyph = self.PLAYER_ON_GOAL if self._player in self._goals else self.PLAYER
        frame[self._player.row][self._player.col] = player_glyph
        return frame

    def _load_level(self, level_index: int) -> None:
        if not 0 <= level_index < len(self.LEVELS):
            raise ValueError(f"Invalid level index: {level_index}")

        level = self.LEVELS[level_index]
        if not level.rows:
            raise ValueError("Level cannot be empty.")

        width = len(level.rows[0])
        if width == 0 or any(len(row) != width for row in level.rows):
            raise ValueError("Level rows must form a non-empty rectangle.")

        terrain: list[list[str]] = []
        goals: set[Position] = set()
        crates: set[Position] = set()
        player: Position | None = None

        valid = {self.WALL, self.FLOOR, self.GOAL, self.CRATE, self.PLAYER,
                 self.CRATE_ON_GOAL, self.PLAYER_ON_GOAL}

        for r, row in enumerate(level.rows):
            parsed_row: list[str] = []
            for c, char in enumerate(row):
                pos = Position(r, c)
                if char not in valid:
                    raise ValueError(f"Invalid level character: {char!r}")

                if char == self.WALL:
                    parsed_row.append(self.WALL)
                elif char in (self.GOAL, self.CRATE_ON_GOAL, self.PLAYER_ON_GOAL):
                    parsed_row.append(self.GOAL)
                else:
                    parsed_row.append(self.FLOOR)

                if char in (self.GOAL, self.CRATE_ON_GOAL, self.PLAYER_ON_GOAL):
                    goals.add(pos)
                if char in (self.CRATE, self.CRATE_ON_GOAL):
                    crates.add(pos)
                if char in (self.PLAYER, self.PLAYER_ON_GOAL):
                    if player is not None:
                        raise ValueError("Level must contain exactly one player.")
                    player = pos

            terrain.append(parsed_row)

        if player is None:
            raise ValueError("Level must contain a player.")
        if not crates:
            raise ValueError("Level must contain at least one crate.")
        if len(crates) != len(goals):
            raise ValueError("Level must have the same number of crates and goals.")

        self.level_index = level_index
        self._terrain = terrain
        self._goals = goals
        self._crates = crates
        self._player = player
        self.moves = 0
        self.pushes = 0
        self.finished = self._is_solved()

    def _in_bounds(self, pos: Position) -> bool:
        return (
            0 <= pos.row < len(self._terrain)
            and 0 <= pos.col < len(self._terrain[0])
        )

    def _is_solved(self) -> bool:
        return self._crates == self._goals

    def _pushes_increment(self) -> None:
        self.pushes += 1
