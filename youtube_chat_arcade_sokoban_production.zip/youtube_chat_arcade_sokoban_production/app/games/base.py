from abc import ABC, abstractmethod
from enum import Enum, auto


class CommandResult(Enum):
    INVALID = auto()
    EXECUTED = auto()


class Game(ABC):
    @abstractmethod
    def handle_command(self, command: str, user_id: str, username: str) -> CommandResult:
        """Process one command. INVALID means the command should be discarded."""
        raise NotImplementedError

    @abstractmethod
    def update(self) -> None:
        """Advance automatic/time-based state, if any."""
        raise NotImplementedError

    @abstractmethod
    def render(self) -> list[list[str]]:
        """Return a rectangular character grid."""
        raise NotImplementedError

    @abstractmethod
    def is_finished(self) -> bool:
        raise NotImplementedError


def render_to_string(frame: list[list[str]]) -> str:
    if not frame:
        return ""

    width = len(frame[0])
    if width == 0:
        return ""

    for row in frame:
        if len(row) != width:
            raise ValueError("Frame must be rectangular.")
        if any(not isinstance(cell, str) or len(cell) != 1 for cell in row):
            raise ValueError("Every frame cell must be exactly one character.")

    return "\n".join("".join(row) for row in frame)
