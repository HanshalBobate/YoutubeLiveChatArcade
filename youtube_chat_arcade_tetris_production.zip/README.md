# YouTube Chat Arcade — Tetris Core

A dependency-free, action-driven Tetris implementation designed for a shared
YouTube-chat controller.

## Commands

```text
!left
!right
!down
!rotate
!drop
```

Aliases:

```text
!l !r !d !rot !up !harddrop
```

Every successfully executed command consumes one chat action window.

## Important behavior

- No realtime keyboard input.
- No mandatory automatic gravity.
- Invalid commands return `CommandResult.INVALID`.
- A valid but impossible movement also returns `INVALID`, allowing the
  command queue to immediately try the next chat message.
- `!down` locks the piece if it cannot move down.
- `!drop` performs a hard drop and locks immediately.
- Lines are cleared and scored after locking.
- The game outputs a rectangular `list[list[str]]`.
- `render_to_string()` converts that frame to OBS-friendly plain text.
- Seeded RNG makes tests deterministic.
