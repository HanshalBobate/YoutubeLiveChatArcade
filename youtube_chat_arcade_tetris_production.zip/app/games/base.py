from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum, auto


class CommandResult(Enum):
    INVALID = auto()
    EXECUTED = auto()


class Game(ABC):
    @abstractmethod
    def handle_command(self, command: str, user_id: str, username: str) -> CommandResult:
        """Process one command and report whether it was executed."""
        raise NotImplementedError

    @abstractmethod
    def update(self) -> None:
        """Advance automatic/time-based state, if any."""
        raise NotImplementedError

    @abstractmethod
    def render(self) -> list[list[str]]:
        """Return the current frame as a rectangular character matrix."""
        raise NotImplementedError

    @abstractmethod
    def is_finished(self) -> bool:
        """Return whether the game has reached a terminal state."""
        raise NotImplementedError


def render_to_string(frame: list[list[str]]) -> str:
    if not frame:
        return ""
    width = len(frame[0])
    if any(len(row) != width for row in frame):
        raise ValueError("Renderer returned a non-rectangular frame.")
    if any(len(cell) != 1 for row in frame for cell in row):
        raise ValueError("Every rendered cell must contain exactly one character.")
    return "\n".join("".join(row) for row in frame)
